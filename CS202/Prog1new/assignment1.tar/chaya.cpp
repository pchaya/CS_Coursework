//Prathyoosha Chaya, CS202 PROGRAMMING SYSTEMS, Prof. Karla Fant
//04/30/2017
//This implementation file includes the main function

#include "maze.h"

int main()
{

    Game cs_game;

    cs_game.begin_game();
    cs_game.play_game();
    
    return 0;

}

