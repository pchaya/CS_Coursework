//Prathyoosha Chaya, CS163 DATA STRUCTURES, Prof. Karla Fant
//Feb. 16, 2017
//This implementation file includes the game class member function definitions.

#include "game_list.h"
#include "card_stack.h"

game::game()
{
    head = NULL;
    array_of_ptr = NULL;

    card_count = 0;
}

game::~game()
{
    if (head)
    {
        delete head;
        head = NULL;
    }

    if (array_of_ptr)
    {
        delete array_of_ptr;
        array_of_ptr = NULL;
    }    
}

bool game::pre_setup()
{
    file_in.open(filename);  //Open file
    bool result = false;
    if (file_in)
        result = read(); 
    else 
        cout << "Error opening " << filename << endl;  
    file_in.close(); 
//  cout << "read" << endl;

/*    display_all();
    cout << "displayed" << endl;
*/  return result;

}

int game::setup()
{
    array_of_ptr = new card_node * [card_count];

    int result = 0;

    if (!head) return result; 

    card_node * current = head;

    for (int i = 0;i<=card_count;++i)
    {
        if (current)
        {
            array_of_ptr[i] = current;
            current = current -> next_card;
        }
    }

    card_stack deck;

    while (deck.number_of_cards < card_count)
    {
        int random_num = rand() % card_count;

        if (array_of_ptr[random_num])
        {
            result = deck.push(array_of_ptr[random_num]);
            array_of_ptr[random_num] = NULL;
        }
        else
        {
            while (!array_of_ptr[random_num])
            {
                ++random_num;
                if (array_of_ptr[random_num])
                {
                    result = deck.push(array_of_ptr[random_num]);
                    array_of_ptr[random_num] = NULL;
                }
            }
        } 
    }
    return result;
}

int game::add_card(card & user_card)
{
    card_node * temp = new card_node;
    temp -> card_data.set_card_data(user_card.subject, user_card.ques, user_card.level, user_card.desc);

   //add to head
 
    if (!head)
    {
        head = temp;
    } 
    
    else if (head)
    {
        card_node * temp2 = head;
        head = temp;
        head -> next_card = temp2; 
    }
    
    ++card_count;

    return 1;
}
/*bool game::rem_card(int to_remove)
{
    if (!head)
        return false;

    //display w/ number

    return ;
} 
*/
//display_all function: Displays all of the cards in order of added. Wrapper function for display_all_worker function. To prevent from passing in a pointer to the list as a parameter.
//Parameters: None.
//Return Value: Boolean value of success or failure (empty list)
bool game::display_all()
{
    int card_index = 0;
    bool result = false;
    if (!head)
        return result;
    card_node * current = head;
    while (current)
    {   
        cout << endl << ++card_index << ":" << endl;
        display_a_node(current);
        current = current -> next_card;
    }
    result = true;
    return result;
}

bool game::display_a_node(card_node * a_node)
{
    if(!a_node)
        return false;
    else {
        cout << "Subject: " << a_node -> card_data.subject << endl
        << "Question: " << a_node -> card_data.ques << endl
        << "Level: " << a_node -> card_data.level << endl
        << "Description: " << a_node -> card_data.desc << endl;
        
    }
    return true;
}

bool game::write(card_node * head)
{
    if (!head)
        return false;

    file_out.open(filename);
    
    //check if file opened successfully
    if (!file_out)
        cout << "Error opening file." << endl;
    else
    {
        file_out << head -> card_data.subject << ";";
        file_out << head -> card_data.ques << ";";
        file_out << head -> card_data.level << ";";
        file_out << head -> card_data.desc << "\n";
    }
    
    write (head -> next_card);
    return true;
}    

bool game::read()      
{
    if (!file_in)
        return false;
    
    //temporary arrays to read into
    char temp_subject [MAX_SIZE_SUBJECT];
    char temp_ques [MAX_SIZE_QUES];
    char temp_desc [MAX_SIZE_DESC];
    int temp_level = 0;


    //initial check to set eof
    file_in.get(temp_subject, MAX_SIZE_SUBJECT - 1, ';');
    file_in.ignore(100, ';');
    
    cout << "1..";
    if (!file_in.eof())
    {
        //if reading operation is successful
        //read the record 
        file_in.get(temp_ques, MAX_SIZE_QUES - 1, ';');
        file_in.ignore(100, ';');

        file_in >> temp_level;
        file_in.ignore(100, ';');

        file_in.get(temp_desc, MAX_SIZE_DESC - 1, '\n');
        file_in.ignore(100, '\n');

    }
    else return true;   //end of items, leave recursion

    //create new node and add data to it
    card_node * temp = new card_node;
    temp -> card_data.set_card_data(temp_subject, temp_ques, temp_level, temp_desc);

    //list management
    if (!head)
    {
        head = temp;
    } 
    
    else if (head)
    {
        card_node * temp2 = head;
        head = temp;
        head -> next_card = temp2; 
    }
    
    ++card_count;

    cout << card_count << endl;
    display_a_node(head);

    return read ();
}



