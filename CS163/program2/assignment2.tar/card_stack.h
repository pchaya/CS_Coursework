//Prathyoosha Chaya, CS 163 DATA STRUCTURES, Prof. Karla Fant
//Feb. 15, 2017
//This header file includes the class definition for the card stack, along with
//the member functions such as push, pop, and peek to view cards in the stack.
//It also contains the pointer to the LLL of arrays (stack).

#ifndef _CARD_STACK_
#define _CARD_STACK_
#include "game_list.h"

class card_stack
{
    public:
        card_stack();
        ~card_stack();
        int push(card_node *);
        int pop();
        int number_of_cards;

    private:
        int display(card_node *);
        card_node * stack_head;
        };


#endif
