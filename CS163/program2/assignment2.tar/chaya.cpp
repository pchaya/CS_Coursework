//Prathyoosha Chaya, CS 163 DATA STRUCTURES, Prof. Karla Fant
//Feb. 15, 2017
//This implementation file includes the main function as well as some supplemental utility functions.

#include "game_list.h"
#include "card_stack.h"

int menu(bool);

int main()
{
    struct timeval start_time;
    gettimeofday (&start_time, NULL);
    srand(start_time.tv_usec);

    //Instance of card to pass into functions
    card user_card;
    game trivia;
    
    bool playing = false;   //set to true if user starts playing game
    bool run_again = true;
    int user_option = 0;
    bool bool_result = false; //function returns
   
    int int_result = 0;       //function returns
    
    //    card_list deck;

    cout << "Welcome to the CS163 trivia game." << endl;
 
    bool_result = trivia.pre_setup();   
    cout << int_result << endl;
    //bool_result = trivia.display_all();
    
    char user_subject [MAX_SIZE_SUBJECT];
    char user_ques [MAX_SIZE_QUES];
    int user_level = 0;
    char user_desc [MAX_SIZE_DESC];

    while (run_again)   //Displays menu to ask user for next steps
    {
        user_option = menu(playing);
        switch (user_option)
        {
            case 1: bool_result = trivia.display_all();
                    if (!bool_result)
                        cout << "No cards currently." << endl;
                    break;
            case 2: cout << "Add card: " << endl;
                    cout << "Subject: ";
                    cin.get (user_subject, MAX_SIZE_SUBJECT, '\n');
                    cin.ignore(100, '\n');
                    
                    cout << endl << "Question: ";
                    cin.get (user_ques, MAX_SIZE_QUES, '\n');
                    cin.ignore(100, '\n');
                    
                    cout << endl << "Level (1-10): ";
                    cin >> user_level;
                    cin.ignore(100, '\n');
                    
                    cout << endl << "Description/hint: ";
                    cin.get(user_desc, MAX_SIZE_DESC, '\n');
                    cin.ignore(100, '\n');

                    user_card.set_card_data(user_subject, user_ques, user_level, user_desc);

                    trivia.add_card(user_card);
                    break; 
            case 3: 
            case 4: run_again = false;
                    break;

            default: cout << "Invalid menu choice." << endl;
                     break;
        } 
    } 


    return 0;
}

//menu function: Outputs the menu for the user to select
//Parameters: None.
//Return Values: Integer of user-inputted menu selection.
int menu(bool playing)
{
    int option = 0;
    cout << endl;

    if (!playing)
    {
        cout << "\t1: Display all cards.\n"
            "\t2: Add a new card.\n"
            "\t3: Play!\n"
            "\t4: Quit game.\n";
            cout << "Please choose the number of which option to execute: ";
        cin >> option;
        cin.ignore(100, '\n');
    }
    else
    {
        cout << "\t1: Draw a card.\n"
            "\t5: Save and quit game.\n"
            "\t6: Quit game without saving cards.\n";
            cout << "Please choose the number of which option to execute: ";
        cin >> option;
        cin.ignore(100, '\n');
    }

    return option;
}


