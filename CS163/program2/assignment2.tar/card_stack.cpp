//Prathyoosha Chaya, CS 163 DATA STRUCTURES, Prof Karla Fant
//Feb. 16, 2017
//This imolementatiob file includes the card class member function definitions.

#include "card_stack.h"
#include "game_list.h"

card_stack::card_stack()
{
   stack_head = NULL;
    number_of_cards = 0;
}


card_stack::~card_stack()
{
    if (!stack_head){
        delete stack_head;
        stack_head = NULL;
    }
}

int card_stack::push(card_node * to_add)
{
    //copy informaiton:
    card_node * temp = new card_node;
    strcpy(temp -> card_data.subject, to_add -> card_data.subject);
    strcpy(temp -> card_data.ques, to_add -> card_data.subject);
    temp -> card_data.level = to_add -> card_data.level;
    strcpy(temp -> card_data.desc, to_add -> card_data.desc); 

    if (!stack_head)
    {
        stack_head = temp;    
    }       
    else
    {
        card_node * temp2 = stack_head;
        stack_head = temp;
        stack_head -> next_card = temp2;
    } 
    ++number_of_cards;
    return 1;

}

int card_stack::pop()
{
    int result = 0;
    if (!stack_head) return 0;

    else if (!stack_head -> next_card)
    {
        result = display(stack_head);
        delete stack_head;
        stack_head = NULL;
    }
    else
    {
        card_node * temp = stack_head -> next_card;
        result = display(stack_head);
        delete stack_head;
        stack_head = temp; 
    }

    return result;
}

int card_stack::display(card_node * to_display)
{
    cout << endl << "Subject: " << to_display -> card_data.subject
        << endl << "Question: " << to_display -> card_data.ques
        << endl << "Level: " << to_display -> card_data.level
        << endl << "Description: " << to_display -> card_data.desc << endl;
    return 0;
}
