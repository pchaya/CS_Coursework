//Prathyoosha Chaya, CS163 DATA  STRUCTURES, Prof. Karla Fant
//Feb. 15, 2017
//This header file includes the class definition for the list of games compiled before it is pushed onto the stack. It also includes member functions dedicated to reading/writing card information into a file, and the pointers to a LLL for storing cards and to a dynamic array of pointers.

#ifndef _GAME_LIST_
#define _GAME_LIST_

#include <iostream>
#include <cctype>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <sys/time.h>

using namespace std;

const char filename [20] = "game.txt";

const int MAX_SIZE_SUBJECT = 101;
const int MAX_SIZE_QUES = 301;
const int MAX_SIZE_DESC = 501;

//card class for data members of each card
struct card
{
    char * subject;
    char * ques;
    int level;
    char * desc;

    //initialize these values when a new instance is created.
    card()
    {
        subject = NULL;
        ques = NULL;
        level = 0;
        desc = NULL;
    }

    void set_card_data(char user_subject [], char user_ques [], int user_level, char user_desc [])
    {
        subject = new char [strlen(user_subject) +1];
        strcpy(subject, user_subject);

        ques = new char [strlen(user_ques) +1];
        strcpy(ques, user_ques);
         
        desc = new char [strlen(user_desc) +1]; 
        strcpy(desc, user_desc); 
        
        level = user_level;
    }


    ~card()
    {
        if (!subject)
        {
            subject = NULL;
            delete [] subject;
        }

        if (!ques)
        {
            ques = NULL;
            delete [] ques;
        }

        if (!desc)
        {
            desc = NULL;
            delete [] desc;
        }
    }
    
};

//card_node struct for LLL
struct card_node
{
    card card_data;
    card_node * next_card;

    card_node()
    {
        next_card = NULL;
    }

};
//game class with all member functions to alter cards and setup/start game 
class game
{
    public:
        game();
        ~game();
        bool pre_setup();                   //from main
        int setup();                        //setup deck, wrapper for read
        int add_card(card & user_card);
        bool rem_card(int to_remove); 
        bool display_all();
        //bool play();
        bool quit (bool save);              //call to exit/save&exit, wrapper for write
        int card_count;
    private:    
        bool write(card_node * head);       //allows to write to file at end of runtime, before quit.
        bool read();      //reads any existing cards from file.
        bool display_a_node(card_node * a_node);      
        card_node * head;   //pointer to start of LLL
        card_node ** array_of_ptr;  //pointer to array of pointers
        ifstream file_in;      //variables for file IO
        ofstream file_out;
};

#endif


