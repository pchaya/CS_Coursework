//Prathyoosha Chaya, CS162
//Nov. 29 2016
//This implemention file includes class member functions.

#include "subject_list.h"

subject_list::subject_list(int max_num_subjects)
{
    m_psubjects = new subject [max_num_subjects];
    m_subject_count = 0;
    m_max_num_subjects = max_num_subjects;
    
    if(m_psubjects)
        load();
}

subject_list::~subject_list()
{
    if (m_psubjects)
        delete [] m_psubjects;
}


//display function: Displays all subjects with their corresponding learned information, rating, and improv. ideas
//Parameters: None.
//Return values: None.
void subject_list::display ()
{
    int i = 0;
    cout << endl << m_subject_count << " archived subjects in database: " << endl;
    cout << "********************************" << endl;
    while (i < m_subject_count)
    {
        cout << "Subject name: " << m_psubjects[i].name << "\n";
        cout << "Information learned: " << m_psubjects[i].learned_info << "\n";
        cout << "Rating: " << m_psubjects[i].rating << "\n";
        cout << "Improvement ideas: " << m_psubjects[i].improve_info;
        cout << endl << endl;
        ++i;
    } 
}


//Load function: Take information of text file and store into array of char.
//Parameters: None.
//Return values: None.
void subject_list::load()
{
    if (!m_psubjects)
    {
        cout << "Dynamic subject list not allocated." << endl;
        return;
    }
    //Create file input stream variable
    ifstream file_in;
    //Open file for input with string literal filename
    file_in.open("subject.txt");
    if (file_in) //to check if connected
    {
        //initial check to set eof
        file_in.get(m_psubjects[m_subject_count].name, SIZE_NAME, ';');
        file_in.ignore(100, ';');
    
        //if reading operation is successful
        while (file_in && !file_in.eof() && m_subject_count <= m_max_num_subjects)
        {
            file_in.get(m_psubjects[m_subject_count].learned_info, SIZE_INFO, ';');
            file_in.ignore(100, ';');
            file_in >> m_psubjects[m_subject_count].rating;
            file_in.ignore(100, ';');
            file_in.get(m_psubjects[m_subject_count].improve_info, SIZE_INFO, '\n');
            file_in.ignore(100,'\n');
            
        //    cout << m_psubjects[m_subject_count].name << endl;
        //    cout << m_psubjects[m_subject_count].learned_info << endl;
        //    cout << m_psubjects[m_subject_count].rating << endl;
        //    cout << m_psubjects[m_subject_count].improve_info << endl;

            ++m_subject_count;
            
            //Move to next subject, then check first element for eof
            file_in.get(m_psubjects[m_subject_count].name, SIZE_NAME, ';');
            file_in.ignore(100, ';');
            
        }
        file_in.close();;
    }
    else
        cout << "Error opening file subject.txt." << endl;

}

//read function: Adds new subjects to end of dynamic array.
//Parameters: None.
//Return values: None.
void subject_list::read()
{
    bool correct_rating = false; //to check if rating is between 0-10
    if (m_subject_count < m_max_num_subjects)
    {
        cout << "Please enter the name of the new subject: ";
        cin.get(m_psubjects[m_subject_count].name, SIZE_NAME, '\n');
        cin.ignore(100, '\n');
        cout << "Please enter information learned of the new subject: ";
        cin.get(m_psubjects[m_subject_count].learned_info, SIZE_INFO, '\n');
        cin.ignore(100, '\n');

        while (correct_rating == false)  //if user enters an invalid rating, the rating is not changed.
        {
            cout << "Please enter your rating of understanding this subject (0-10): ";
            cin >> m_psubjects[m_subject_count].rating;
            if (m_psubjects[m_subject_count].rating < 0 || m_psubjects[m_subject_count].rating > 10)
                cout << "Invalid rating. Rate from 0-10." << endl;
            else
                correct_rating = true;
        }
        cin.ignore(100, '\n');
        cout << "Please enter improvement ideas for the new subject: ";
        cin.get(m_psubjects[m_subject_count].improve_info, SIZE_INFO, '\n');
        cin.ignore(100, '\n');

        ++m_subject_count; //Increase current number of subjects
    }
    else
        cout << "Subjects full." << endl;
}


//write function: Writes contents of array back to file.
//Parameters: None.
//Return values: None.
void subject_list::write()
{
    //Create file output stream variable and index
    ofstream file_out;
    int i = 0;

    //Open file for output with string literal filename. Overwrite everything.
    file_out.open("subject.txt");

    //Check if file has successfully opened.
    if (!file_out)
        cout << "Error opening file." << endl;
    else
    {
        while (i < m_subject_count)
        {
            file_out << m_psubjects[i].name << ";";
            file_out << m_psubjects[i].learned_info << ";";
            file_out << m_psubjects[i].rating << ";";
            file_out << m_psubjects[i].improve_info << "\n";
            ++i;
        }
        file_out.close();
        cout << "Changes sucessfully saved to subject.txt" << endl;
    }
}


//search function: Searches for a match among all the existing subjects in the array.
//Parameters: User inputted subject.
//Return values: Index number of the subject if found, '-1' if not found.
int subject_list::search (char user_subject [])
{
    bool match_found = false;
    cout << endl << endl;

    int search_index = 0; //to store the index of subject's improvement info to be modified
    int return_val = -1;  
    char upper_subject[SIZE_NAME];
    char upper_name[SIZE_NAME];
    
    //Check for matches between user inputted subject and existing subjects
    for (search_index = 0; (search_index < m_subject_count && match_found == false); ++search_index)
    {
        upper_subject[0] = '\0';
        upper_name[0] = '\0';
        convert_upper(user_subject, upper_subject);
        convert_upper(m_psubjects[search_index].name, upper_name);
        
        if (strcmp(upper_subject, upper_name) == 0) //calls convert_upper function, as toupper only converts one character to uppercase
        {
            match_found = true;
            return_val = search_index;
        }

    }

    
    if (match_found == false)
        cout << "Subject not found." << endl;
    
    //cout << return_val;
    return return_val;
}

//remove function: This function removes an existing subject that the user has identified.
//Parameters: None.
//Return Values: None.
void subject_list::remove()
{
    char user_subject[SIZE_INFO]; //for the user's choice of subject
    int subject_index = 0;

    for (int i = 0; i < m_subject_count; ++i)
        cout << m_psubjects[i].name << endl;
    cout << "Please enter the name of the subject above to remove: ";
    cin.get(user_subject, '\n');
    cin.ignore(100, '\n');
    
    subject_index = search(user_subject);
    if(subject_index != -1)
    {
        for (int i = subject_index; i < m_subject_count; ++i)
        {
            strcpy(m_psubjects[i].name, m_psubjects[i+1].name);
            strcpy(m_psubjects[i].learned_info, m_psubjects[i+1].learned_info);
            m_psubjects[i].rating = m_psubjects[i+1].rating;
            strcpy(m_psubjects[i].improve_info, m_psubjects[i+1].improve_info);
        }
    }
    cout << user_subject << " removed." << endl;
}

//convert_upper function: Converts arrays of characters to uppercase to later compare user-inputted subject to existing subjects. Used for search function.
//Parameters: Original array, and uppercase array
//Return values: None.
void subject_list::convert_upper(char source[], char destination[])
{
    int i;
    //int size = sizeof(destination);
    memset(destination, 0, SIZE_NAME);
    //setting all values to NOT null terminating char, so that if previous destination array was shorter than current ("Arrays" vs. "Control Structures"), then the next loop will not terminate early.
    for(i = 0; source[i] != '\0'; ++i) //converts a char array to uppercase for use in other functions.
        destination[i] = toupper(source[i]);
    destination[i+1] = '\0';
}

