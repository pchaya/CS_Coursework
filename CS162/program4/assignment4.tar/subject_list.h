//Prathyoosha Chaya, CS 162
//Nov. 29 2016
//This header file contains the function prototypes, constants, struct definition, and the class interface.

#ifndef _subject_list_    //To prevent from compiling this header file multiple times
#define _subject_list_    //Define after entered once

#include <iostream>
#include <fstream>
#include <cctype>
#include <cstring>

using namespace std;

const int SIZE_NAME = 21;
const int SIZE_INFO = 301;

struct subject
{
    char name[SIZE_NAME];
    char learned_info[SIZE_INFO];
    int rating;
    char improve_info[SIZE_INFO];
};

class subject_list
{
    public:
        subject_list(int max_num_subjects = 20);
        ~subject_list();
        void read ();
        void load ();
        void display ();
        void write ();
        int search (char user_subject []);
        void remove ();

    private:
        subject * m_psubjects;
        int m_subject_count;
        int m_max_num_subjects;
        void convert_upper(char source[], char destination[]);

};

#endif
